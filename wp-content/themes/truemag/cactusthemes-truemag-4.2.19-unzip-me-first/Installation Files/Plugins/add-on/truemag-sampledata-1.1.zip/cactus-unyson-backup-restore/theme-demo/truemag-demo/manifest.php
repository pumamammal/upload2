<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }
$manifest = array();
$manifest['title'] = esc_html__( 'Main Demo', 'truemag' );
$manifest['screenshot'] = 'http://truemag.cactusthemes.com/wp-content/uploads/2013/11/screenshot.png';
$manifest['preview_link'] = 'http://truemag.cactusthemes.com/';
$manifest['demo_link'] = 'http://truemag.cactusthemes.com/sample/truemag-demo.zip';
